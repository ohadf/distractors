
image_filenames = dir('./*.jpg');

for img_file = {image_filenames.name}
  img = imread(img_file{1});
  [text_mask] = img2textmask(img);
  imshowpair(img, text_mask);
  pause;
end