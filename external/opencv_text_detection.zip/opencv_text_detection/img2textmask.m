function [text_mask] = img2textmask(img)
%IMG2TEXTMASK Summary of this function goes here
%   Detailed explanation goes here

  PATH_TO_TEXT_DETECTOR = 'CHANGE ME';
  PATH_TO_TEXT_DETECTOR = '/Users/fried/Google Drive/University/PhD/De-Saliency/For Release/distractors_code/external/opencv_text_detection/';
  
  % ugly hack! we change directory and change back so that the .xml files
  % will be found
  orig_dir = pwd();
  cd(PATH_TO_TEXT_DETECTOR);
  
  text_bb = textdetection(img) + 1;
  
  text_mask = false(size(img, 1), size(img, 2));
  for ii = 1:size(text_bb, 1)
    bb = text_bb(ii, :);
    text_mask(bb(2):(bb(2) + bb(4) - 1), bb(1):(bb(1) + bb(3) - 1)) = true;
  end
  
  cd(orig_dir);
end

