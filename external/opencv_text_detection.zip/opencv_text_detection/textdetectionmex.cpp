/*
 * textdetectionmex.cpp - detect text (wrapper for opencv)
 *
 * The calling syntax is:
 *
 *		outCoordinates = textdetectionmex(img)
 *
 * This is a MEX-file for MATLAB. Adapted from opencv3.
*/

// We allow C++11 extension
#pragma clang diagnostic ignored "-Wc++11-extensions"

#include "mex.h"
#include "matrix.h"

#include  "opencv2/core/core.hpp"
#include  "opencv2/text.hpp"
#include  "opencv2/highgui.hpp"
#include  "opencv2/imgproc.hpp"

#include  <iostream>

using namespace std;
using namespace cv;
using namespace cv::text;

// Forward declerations
void doit(const unsigned char* img, unsigned int nrows, unsigned int ncols, mxArray** out_array_p);


/* The mex gateway function */
void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
  // Check input/output validity

  if (nrhs != 1) {
    mexErrMsgIdAndTxt("MyToolbox:textdetectionmex:nrhs", "One input required.");
  }
  if (nlhs != 1) {
    mexErrMsgIdAndTxt("MyToolbox:textdetectionmex:nlhs", "One output required.");
  }
  if (!mxIsUint8(prhs[0])) {
    mexErrMsgIdAndTxt("MyToolbox:textdetectionmex:notDouble", "Input image must be type uint8.");
  }
  // Check number of dims, make sure the image is 3D
  if (3 != mxGetNumberOfDimensions(prhs[0])) {
    mexErrMsgIdAndTxt("MyToolbox:textdetectionmex:wrongImgDimNumber", "Input image must have 3 dimentions.");
  }
  // make sure we have 3 color channels
  const mwSize * img_dims = mxGetDimensions(prhs[0]);
  if (3 != img_dims[2]) {
    mexErrMsgIdAndTxt("MyToolbox:textdetectionmex:wrongImgDim", "Input image must have 3 color channels.");
  }

  // create a pointer to the real data in the input matrix (MxNx3)
  unsigned char *img = (unsigned char *)mxGetData(prhs[0]);

  // text detection
  doit(img, img_dims[0], img_dims[1], &(plhs[0]));
}

void doit(const unsigned char* img, unsigned int nrows, unsigned int ncols, mxArray** out_array_p) {
  // Create opencv Mat from the input matrix
  Mat src(Size(ncols,nrows), CV_8UC3);
  for (unsigned int x = 0 ; x < ncols ; ++x) {
    for (unsigned int y = 0 ; y < nrows ; ++y) {
      unsigned int ind = x * nrows + y;
      Vec3b pixel_rgb(img[ind + 2 * nrows * ncols], img[ind + nrows * ncols], img[ind]);
      src.at<Vec3b>(Point(x, y)) = pixel_rgb;
    }
  }

  // Extract channels to be processed individually
  vector<Mat> channels;
  computeNMChannels(src, channels);

  int cn = (int)channels.size();
  // Append negative channels to detect ER- (bright regions over dark background)
  for (int c = 0; c < cn-1; c++) {
    channels.push_back(255-channels[c]);
  }

  // Create ERFilter objects with the 1st and 2nd stage default classifiers
  Ptr<ERFilter> er_filter1 = createERFilterNM1(loadClassifierNM1("trained_classifierNM1.xml"),16,0.00015f,0.13f,0.2f,true,0.1f);
  Ptr<ERFilter> er_filter2 = createERFilterNM2(loadClassifierNM2("trained_classifierNM2.xml"),0.5);

  vector<vector<ERStat> > regions(channels.size());
  // Apply the default cascade classifier to each independent channel (could be done in parallel)
  //mexPrintf("Extracting Class Specific Extremal Regions from %d channels ...\n", (int)channels.size());
  for (int c=0; c<(int)channels.size(); c++) {
    er_filter1->run(channels[c], regions[c]);
    er_filter2->run(channels[c], regions[c]);
  }

  // Detect character groups
  vector< vector<Vec2i> > region_groups;
  vector<Rect> groups_boxes;
  //erGrouping(src, channels, regions, region_groups, groups_boxes, ERGROUPING_ORIENTATION_HORIZ);
  erGrouping(src, channels, regions, region_groups, groups_boxes, ERGROUPING_ORIENTATION_ANY, "./trained_classifier_erGrouping.xml", 0.5);

  // Allocate output array
  *out_array_p = mxCreateDoubleMatrix(groups_boxes.size(), 4, mxREAL);
  // get a pointer to the real data in the output matrix
  double* out_rects = mxGetPr(*out_array_p);

  // iterate all output rects, copy to output matrix
  unsigned int i = 0;
  for (auto curr_rect : groups_boxes) {
    out_rects[i                            ] = curr_rect.x;
    out_rects[i   +     groups_boxes.size()] = curr_rect.y;
    out_rects[i   + 2 * groups_boxes.size()] = curr_rect.width;
    out_rects[i++ + 3 * groups_boxes.size()] = curr_rect.height;
  }

  // memory clean-up
  er_filter1.release();
  er_filter2.release();
  regions.clear();
  if (!groups_boxes.empty()) {
    groups_boxes.clear();
  }
}
